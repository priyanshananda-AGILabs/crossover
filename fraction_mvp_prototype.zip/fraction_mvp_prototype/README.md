# Fraction Studio MVP Prototype

This is a self-contained HTML/CSS/JavaScript prototype for the recommended MVP approach: a private, high-school-appropriate adaptive fraction-comparison practice flow.

## How to run

Open `index.html` in any modern browser. No build step, package install, or internet connection is required.

For a deterministic walkthrough, open:

`index.html?demo=1`

## What the prototype demonstrates

- A student starts a private practice run without a separate diagnostic.
- The app presents fraction-comparison problems tagged by strategy type.
- Correct answers preserve momentum.
- Wrong answers avoid a harsh red-X moment and show a short strategy card with a visual model.
- After a wrong answer, the next question is a paired retry of the same type.
- Skill-level stats update privately, and the adaptive note explains why a type is being repeated.

## MVP limitations

This prototype is student-facing only. It does not include accounts, persistence, teacher dashboards, a full item bank, formal mastery logic, or accessibility QA beyond basic semantic structure.
